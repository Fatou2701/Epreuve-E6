const express = require('express');
const path = require('path');
const connectDB = require('./config/db');

const userRoutes = require('./routes/userRoutes');
const bookingRoutes = require('./routes/bookingRoutes');

const app = express();
const PORT = 3000;

// Middleware
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, 'public')));

// Routes
app.use('/api/users', userRoutes);
app.use('/api/bookings', bookingRoutes);

// Views
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'views/index.html')));
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, 'views/dashboard.html')));
app.get('/booking', (req, res) => res.sendFile(path.join(__dirname, 'views/booking.html')));

// Database Connection
connectDB();

// Start Server
app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));
