const User = require('../models/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

// Clé secrète pour JWT (à déplacer vers un fichier de configuration sécurisé)
const JWT_SECRET = 'your_secret_key_here';

// Fonction pour générer un token JWT
const generateToken = (user) => {
    return jwt.sign(
        { id: user._id, email: user.email },
        JWT_SECRET,
        { expiresIn: '7d' } // Token valable pendant 7 jours
    );
};

// Inscription d'un utilisateur
exports.register = async (req, res) => {
    const { name, email, password } = req.body;

    try {
        // Vérifier si l'utilisateur existe déjà
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: 'Email already in use' });
        }

        // Hacher le mot de passe
        const hashedPassword = await bcrypt.hash(password, 10);

        // Créer un nouvel utilisateur
        const newUser = new User({ name, email, password: hashedPassword });
        await newUser.save();

        // Générer un token pour l'utilisateur
        const token = generateToken(newUser);

        res.status(201).json({
            message: 'User registered successfully',
            user: { id: newUser._id, name: newUser.name, email: newUser.email },
            token
        });
    } catch (error) {
        res.status(500).json({ message: 'Error registering user', error });
    }
};

// Connexion d'un utilisateur
exports.login = async (req, res) => {
    const { email, password } = req.body;

    try {
        // Trouver l'utilisateur par email
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        // Comparer les mots de passe
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        // Générer un token pour l'utilisateur
        const token = generateToken(user);

        res.status(200).json({
            message: 'Login successful',
            user: { id: user._id, name: user.name, email: user.email },
            token
        });
    } catch (error) {
        res.status(500).json({ message: 'Error logging in', error });
    }
};

// Middleware pour vérifier le token JWT
exports.protect = async (req, res, next) => {
    const token = req.headers.authorization?.split(' ')[1]; // Récupérer le token dans les en-têtes

    if (!token) {
        return res.status(401).json({ message: 'No token provided, authorization denied' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded; // Ajouter les infos utilisateur au req pour usage ultérieur
        next();
    } catch (error) {
        res.status(401).json({ message: 'Token is invalid or expired', error });
    }
};
