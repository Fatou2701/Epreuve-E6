const Booking = require('../models/Booking');

// Créer une réservation
exports.createBooking = async (req, res) => {
    const { userId, type, location, date } = req.body;
    try {
        const newBooking = new Booking({ userId, type, location, date });
        await newBooking.save();
        res.status(201).json({ message: 'Booking created successfully', booking: newBooking });
    } catch (error) {
        res.status(500).json({ message: 'Error creating booking', error });
    }
};

// Récupérer les réservations d'un utilisateur
exports.getUserBookings = async (req, res) => {
    const userId = req.params.userId;
    try {
        const bookings = await Booking.find({ userId });
        res.status(200).json(bookings);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching bookings', error });
    }
};

// Annuler une réservation
exports.cancelBooking = async (req, res) => {
    const bookingId = req.params.id;
    try {
        const deletedBooking = await Booking.findByIdAndDelete(bookingId);
        if (!deletedBooking) {
            return res.status(404).json({ message: 'Booking not found' });
        }

        res.status(200).json({ message: 'Booking cancelled successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error cancelling booking', error });
    }
};
