exports.getWorkouts = (req, res) => {
    // Exemple : récupérer les programmes d'entraînement depuis la base de données
    res.json([
        { id: 1, name: 'Cardio rapide', duration: '30 min', difficulty: 'Intermédiaire' },
        { id: 2, name: 'Yoga débutant', duration: '20 min', difficulty: 'Débutant' },
    ]);
};

exports.getWorkoutById = (req, res) => {
    const workoutId = req.params.id;
    // Exemple : chercher un programme spécifique
    res.json({ id: workoutId, name: 'Cardio rapide', duration: '30 min', difficulty: 'Intermédiaire' });
};

exports.recommendWorkout = (req, res) => {
    // Exemple : générer des recommandations basées sur l'utilisateur
    res.json({ recommendation: 'Essayez une séance de Yoga pour améliorer votre flexibilité.' });
};

