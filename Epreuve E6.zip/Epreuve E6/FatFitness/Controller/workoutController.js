const Workout = require('../models/Workout');

// Ajouter un programme d'entraînement
exports.addWorkout = async (req, res) => {
    const { title, description, duration, level, category, videoUrl } = req.body;
    try {
        const newWorkout = new Workout({ title, description, duration, level, category, videoUrl });
        await newWorkout.save();
        res.status(201).json({ message: 'Workout added successfully', workout: newWorkout });
    } catch (error) {
        res.status(500).json({ message: 'Error adding workout', error });
    }
};

// Récupérer tous les programmes d'entraînement
exports.getAllWorkouts = async (req, res) => {
    try {
        const workouts = await Workout.find();
        res.status(200).json(workouts);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching workouts', error });
    }
};

// Récupérer un programme par ID
exports.getWorkoutById = async (req, res) => {
    const workoutId = req.params.id;
    try {
        const workout = await Workout.findById(workoutId);
        if (!workout) {
            return res.status(404).json({ message: 'Workout not found' });
        }

        res.status(200).json(workout);
    } catch (error) {
        res.status(500).json({ message: 'Error fetching workout', error });
    }
};

// Supprimer un programme
exports.deleteWorkout = async (req, res) => {
    const workoutId = req.params.id;
    try {
        const deletedWorkout = await Workout.findByIdAndDelete(workoutId);
        if (!deletedWorkout) {
            return res.status(404).json({ message: 'Workout not found' });
        }

        res.status(200).json({ message: 'Workout deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error deleting workout', error });
    }
};
