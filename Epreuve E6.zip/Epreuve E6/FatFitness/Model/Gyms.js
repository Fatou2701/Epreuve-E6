const mongoose = require('mongoose');

const gymSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true,
    },
    address: {
        type: String,
        required: true,
    },
    city: {
        type: String,
        required: true,
    },
    capacity: {
        type: Number,
        required: true,
    },
    amenities: {
        type: [String], // Liste des équipements (ex. "WiFi", "Douches", etc.)
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('Gym', gymSchema);
