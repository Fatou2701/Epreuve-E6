const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true,
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
    },
    password: {
        type: String,
        required: true,
    },
    role: {
        type: String,
        enum: ['user', 'coach', 'admin'],
        default: 'user',
    },
    preferences: {
        goals: { type: String, enum: ['weight_loss', 'muscle_gain', 'fitness'], default: 'fitness' },
        level: { type: String, enum: ['beginner', 'intermediate', 'advanced'], default: 'beginner' },
    },
    performance: {
        totalWorkouts: { type: Number, default: 0 },
        caloriesBurned: { type: Number, default: 0 },
    },
    createdAt: {
        type: Date,
        default: Date.now,
    },
});

module.exports = mongoose.model('User', userSchema);
